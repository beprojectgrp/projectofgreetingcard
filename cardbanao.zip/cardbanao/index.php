<!DOCTYPE html>
<html>
<head>

  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="style1.css">
  <link href='http://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'>
  
  <title>CardBanao</title>
  <style>
    .img {
      width:304px;
      height:228px;
      padding: 10px;
      background-color: white;
      margin-right: 20px;
      margin-top : 20px;
    }

    .alert {
      background-color: white;
      padding: 10px;
      width: 80%;
      margin: auto;
      margin-top: 10px;
      text-align: center;
    } 
    

    li {
      float :left;
      list-style-type: none;
    }

    button {
      padding : 10px;
      background-color: #5796E7;

      border : 1px solid #5796E7;
      
      outline : none;
      font-weight: bold;
      color : white;
    }

    button:hover{
      background-color: gray;
      border : 1px solid gray;
      color : white;
    }
  </style>
</head>
<body >

  <?php 
    include "nav.php"; 
    session_start();
  ?>
    
    <div class="body fadeInLeft animated">
      <br>
      <ul>
      <?php 

        require_once("db_connect.php");

        if (isset($_GET['section']))
        {
          $section = $_GET['section'];
          $query = "SELECT * FROM cards WHERE section=$section";      
        }
        else
        {
          $query = "SELECT * FROM cards";
        }




        $result = mysqli_query($con, $query) or die("Something went wrong!! Please Try Again");

        if ($result)
        {
          $num_rows = mysqli_num_rows($result);

          if ($num_rows)
          {
            while($row = mysqli_fetch_array($result))
            {
              $id = $row['id'];
              $name = $row['name'];
              $alt_text = $row['alt_text'];
              $section = $row['section'];
              $url = $row['url'];
              $price = $row['price'];
        ?>
              <li>
                <form action="buy_card.php" method="GET">
                  <input type="hidden" name="card_id" value="<?= $id ?>">
                  <img src='img/<?= $url ?>' class='img'><br>
                  <span style="padding: 10px; background-color: white;">Price : <?= $price; ?>/-</span>
                  <button type="submit">Buy Now</button>
                </form>
              </li>

        <?php
            }
          }
          else
            echo "<p align='center' class='alert'>No Cards Yet, under this sections!!<br>Come back after some time</p>";
        }
        else
          header("Location: index.php");

      ?>
      </ul>
    </div>
  </div>



</body>
</html>
