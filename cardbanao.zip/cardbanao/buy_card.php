<!DOCTYPE html>
<html>
<head>
	<title>Buy Card</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/register.css">
	
	<style>
		.wrapper {
			width: 600px; margin: auto;
			background-color: white;
			margin-top : 30px;
			padding : 20px;
		}

		.alert {
			background-color: white;
			padding: 10px;
			width: 80%;
			margin: auto;
			margin-top: 10px;
			text-align: center;
		}

		.alert a {
			color : white;
			background-color: black;
			padding: 5px;
		}

		.alert a:hover {
			color : black;
			background-color: white;
		}

		table {
			background-color: white;
			/*border : 1px solid black;*/
			/*border-collapse: collapse;*/
			margin-top : 20px;
		}

		td,th {
			/*border: 1px solid black;*/
			padding: 10px;
			/*text-align: center;*/
		}

		button {
			width: 100%;
			padding: 10px;
			border : none;
		}

		button:hover {
			background-color: gray;
		}

		input, textarea {
			width: 90%;
		}
	</style>
</head>
<body>
	
<?php
	include 'nav.php';
	session_start();
	if(!isset($_SESSION['user_id']))
		header('Location: login.php');
	
	
	if (isset($_POST['submit']))
	{

		$user_id = $_SESSION['user_id'];
		$card_id = $_POST['card_id'];
		$contact = $_POST['contact'];
		$address = $_POST['address'];
		
		require_once("db_connect.php");

		$query = "INSERT INTO orders (card_id, user_id, contact, address, datetime, status) VALUES ($card_id, $user_id, '$contact', '$address', NOW(), 'Order Placed')";
		$result = mysqli_query($con, $query) or die("Something went wrong!! Please Try Again");
		echo "<p class='alert'>Your Order Placed!! Track your order in <a href='my_orders.php' >My Orders</a> Tab</p>";
	}
	else
	{

	if (!isset($_GET['card_id']))
		header('Location: index.php');
	else
	{
		include "db_connect.php";

		$card_id = $_GET['card_id'];
		
		$result = mysqli_query($con,"SELECT * FROM cards where id = '$card_id' ");

		$rows = mysqli_num_rows($result);
		if ($rows < 0 )
			echo "<h1>404</h1>";

		$card = mysqli_fetch_assoc($result);
?>
	<div class="">
		<table align="center">
			<form action="" method="POST">
				<input type="hidden" name="card_id" value="<?= $card_id ?>" >
				<tr>
					<td  colspan="2" align="center">
						<img src="img/<?= $card['url'] ?>" width="400px">
					</td>
					
				</tr>

				<tr>
					<td>
						Price
					</td>
					<td>
						<?= $card['price'] ?>
					</td>
				</tr>

				<tr>
					<td>
						<label for="contact">Contact : </label>
					</td>
					<td>
						<input type="text" name="contact" id="contact">
					</td>
				</tr>

				<tr>
					<td>
						<label for="address">Address : </label>
					</td>
					<td>
						<textarea  name="address" id="address"></textarea>
					</td>
				</tr>

				<tr>
					<td colspan="2">
						<button name="submit" type="submit">Place Order</button>
					</td>
				</tr>
			</form>
		</table>

			
<?php

	}

}

?>


</body>
</html>
