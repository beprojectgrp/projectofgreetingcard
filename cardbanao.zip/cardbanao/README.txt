
follow these steps to install:
1. Before installatoion make sure apache server is running
2. When apache server is running , copy this folder in /var/www/html/
3. Go to link http://localhost/phpmyadmin
4. login using your userid and password
5. go to import tab and import db file
6. after setting db up, open db_connect.php and set username and password
7. execute the project with link http://localhost/cardbanao
8. to access admin panel go to link http://localhost/cardbanao/admin
9. use id: admin@cardbanao and pass : admin to login into admin panel

