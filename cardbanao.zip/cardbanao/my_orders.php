<!DOCTYPE html>
<html>
<head>
	<title>My Orders</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<style>
		table {
			background-color: white;
			border : 1px solid black;
			border-collapse: collapse;
			margin-top : 20px;
		}

		td,th {
			border: 1px solid black;
			padding: 10px;
			text-align: center;
		}

		.alert {
			background-color: white;
			padding: 10px;
			width: 80%;
			margin: auto;
			margin-top: 10px;
			text-align: center;
		}

	</style>
</head>
<body>


<?php
	session_start();
	include 'nav.php';
?>

<?php 


		include "db_connect.php";

		$user_id = $_SESSION['user_id'];

		$sql = "select price, o.id,card_id,url,status from orders o, cards c where user_id=$user_id and o.card_id = c.id;";

		$result = mysqli_query($con,$sql) or die("something went wrong! plz try again");

		$num_rows = mysqli_num_rows($result);

		if ($num_rows)
		{

?>
<table width="70%" align="center">
	<tr>
		<th>Order Id</th>
		<th>Card Id</th>
		<th>Image</th>
		<th>Price</th>
		<th>Current Status</th>
	</tr>

	<?php

			while($order = mysqli_fetch_assoc($result))
			{
				$id = $order['id'];
				$price = $order['price'];
				$card_id = $order['card_id'];
				$user_id = $order['user_id'];
				$url = $order['url'];
				$status = $order['status'];
	?>
		<tr>
			<td><?= $id ?></td>
			<td><?= $card_id ?></td>
			<td><img src='img/<?= $url ?>' width='100px'></td>
			<td><?= $price ?></td>
			<td><?= $status ?></td>
		</tr>
	<?php
		}
	} //close of is
	else
		echo "<p class='alert'>No Orders Yet!!</p>";
	?>
</table>


</body>
</html>