<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="css/register.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CardBanao : User Registration</title>
  
  <!-- <link href='http://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'> -->
  
</head>
<body>
  <?php
    // handling form using post method
    if (isset($_POST['submit']))
    {
		require_once("db_connect.php");
		
        $name =  $_POST['name'];
        $email = $_POST['email'];
        $password =  $_POST['password'];
        $query = "INSERT INTO users (name, email, password) VALUES ('$name','$email','$password');";
        echo $query;
        $result = mysqli_query($con, $query) or die("Something went wrong!! Please Try Again");
        
        header("Location: login.php");
    }
    else
    {
    
  ?>

  <?php include "nav.php"; ?>
  <br>
  <form method="post" action="">

    <h1>Sign Up</h1>

      
      <label for="name">Name:</label>
      <input type="text" id="name" name="name" required>

      <label for="mail">Email:</label>
      <input type="email" id="mail" name="email" required>

      <label for="password">Password:</label>
      <input type="password" id="password" name="password" required>
    
    <button type="submit" name="submit">Sign Up</button>
  </form>
  <?php } //close of else ?>


</body>
</html>
