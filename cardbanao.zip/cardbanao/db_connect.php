<?php
$host = "localhost";
$user = "root";
$pass = "root";
$db = "cardbanao";

$con=mysqli_connect($host,$user,$pass,$db);

// Check connection
if (mysqli_connect_errno())
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error()."<br>";
  die();
}
/*
else
{
	echo "Connected to Database !<br>";
}
*/
?>
