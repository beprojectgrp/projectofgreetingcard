<?php session_start(); ?>

<div >
    <h1><p align="center" style="color : #5796E7;text-decoration: underline; background-color: white">CardBanao</p></h1>

    <div class="second">
      <ul>
        <li class="dropdown" style="background-color: gray;">
          <a href="index.php" class="dropbtn">CardBanao</a>
        </li>
        
        <?php 
          require_once("db_connect.php");
  
          $query = "SELECT * FROM sections";
          $result = mysqli_query($con, $query) or die("Something went wrong!! Please Try Again");

          while($row = mysqli_fetch_array($result))
          {
            $id = $row['id'];
            $name = $row['name'];

        ?>

        <li class="dropdown">
          <a href="index.php?section=<?= $id ?>" class="dropbtn"><?php echo $name; ?></a>
        </li>
        <?php 

        } //close of while 
        ?>
        
      
      <?php 
        if (isset($_SESSION['user_id']))
        {

      ?>
        <li class="dropdown">
          <a href="my_orders.php" class="dropbtn">My Orders</a>
        </li>
        <li class="dropdown">
          <a href="" class="dropbtn">Hello <?php echo $_SESSION['name']; ?></a>
        </li>
        
        <li class="dropdown">
          <a href="logout.php" class="dropbtn">Logout</a>
        </li>  
      <?php } //close of if 
        else
        {
      ?>
        <li class="dropdown">
        <a href="register.php" class="dropbtn">Register</a>
        </li>
        <li class="dropdown">

        <a href="login.php" class="dropbtn">Login</a>
        </li>
      <?php } //close of else ?>
      </ul>
    </div>
