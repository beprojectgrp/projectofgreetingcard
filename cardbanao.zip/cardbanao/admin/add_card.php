<?php
  session_start();

  if (isset($_SESSION['user_id']))
  { 
    $username = $_SESSION['name'];
    $admin = $_SESSION['admin'];
    if ($admin != '1')
    {
      echo "not admin";
      header('Location: ../index.php');
    }
  }
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin :: Add Card</title>
  <link rel="stylesheet" type="text/css" href="css/nav.css">
  <style type="text/css">
    .alert {
      background-color: lightgray;
      border-radius: 10px;
      padding: 10px;
      width: 80%;
      margin: auto;
      margin-top: 10px;
      text-align: center;
    }

    .form_table {
      background-color: lightgray;
      border-radius: 10px;
      border : none;
    }

    .form_table td, .form_table th {
      border : none;
      padding: 10px;
    }

    .form_table td input {
      padding : 5px;
    }

    .form_table td button {
      padding : 5px;
      width: 100%;
      background-color : #5796E7;
      border : 0px;
      color : white;
      border-radius: 5px;
    }

    .form_table td button:hover {
      background-color : gray;
      color : white;
    }

    .heading {
      text-align: center;
      color : #5796E7;
      border-bottom : 1px solid black;
    }

  </style>
</head>
<body>
  <?php
    // handling form using post method
    if (isset($_POST['submit']))
    {

      if (!isset($_FILES['image']['tmp_name']))
      {
        echo "error occured here";
      }
      else
      {
        $file=$_FILES['image']['tmp_name'];
        $image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
        $image_name= addslashes($_FILES['image']['name']);


        $date = date_create();
        $timestamp = date_timestamp_get($date);
        $unique = $timestamp + mt_rand(); 

        $_FILES['image']['name'] = $unique;


        move_uploaded_file($_FILES["image"]["tmp_name"],"../img/" . $_FILES["image"]["name"]);

        $location=$_FILES["image"]["name"];
        
      }


      $name = $_POST['name'];
      $price = $_POST['price'];
      $section = $_POST['section'];
		  $url = $location;

      


      require_once("../db_connect.php");
	
      $query = "INSERT INTO cards (name, price, section, url) VALUES ('$name','$price','$section', '$url');";

      $result = mysqli_query($con, $query) or die("Something went wrong!!");
        
      //   header("Location: login.php");
      $msg = "Card Added!!";
    }

  ?>

  <?php include "nav.php"; 
    if(isset($msg))
    {
      echo "<div class='alert'>$msg</div>";
    }

  ?>

    <div style="margin-top : 20px;">
      <form method="post" action="" enctype="multipart/form-data">
        <table border="1" align="center" class="form_table">
          <tr>
            <td colspan="2"><div class="heading"><h2>Add New Card</h2></div></td>
          </tr>

          <tr>
            <td><lable for="name">Name</lable></td>
            <td><input type="text" name="name" id="name" required=""></td>
          </tr>

          <tr>
            <td><lable for="price">Price</lable></td>
            <td><input type="text" name="price" id="price" required=""></td>
          </tr>

          <tr>
            <td><lable for="section">Section</lable></td>
            <td>
              <select name="section" id="section" required="">
                <option value="">Select Section</option>
                <?php 
                  require_once("../db_connect.php");
                  $query = 'SELECT * from sections';
                  $result = mysqli_query($con, $query) or die("Something went wrong");
                  while($row = mysqli_fetch_array($result))
                  {
                    $id = $row['id'];
                    $name = $row['name'];

                    echo "<option value='$id'>$name</option>";
                  }
                ?>
              </select>
            </td>
          </tr>
          
          <tr>
            <td><lable for="image">Image</lable></td>
            <td><input type="file" name="image" id="image" required=""></td>
          </tr>

          <tr>
            <td colspan="2"><button type="submit" name="submit">Submit</button></td>
          </tr>

        </table>
      </form>
    </div>


</body>
</html>
