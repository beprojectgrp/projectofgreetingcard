<table border="1" class="nav" cellspacing="0px">
	<tr>
		<td>CardBanao Admin</td>
		<td><a href="orders.php">Orders</a></td>
		<td><a href="add_card.php">Add Card</a></td>
		<td><a href="../logout.php">Logout</a></td>
	</tr>	
</table>