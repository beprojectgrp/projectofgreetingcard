<?php
	$date = date_create();
	$timestamp = date_timestamp_get($date);
	
	echo $timestamp;
	
	$random  = mt_rand();
	$unique = $timestamp + $random; 
	echo $unique;
?>
