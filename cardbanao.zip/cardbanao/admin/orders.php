<!DOCTYPE html>
<html>
<head>
	<title>Admin : Orders</title>
	<link rel="stylesheet" type="text/css" href="css/nav.css">

	<style type="text/css">
		
	.order_table {
	  border : 1px solid black;
	  border-collapse: collapse;
      border-radius: 10px;
      border : none;
    }
	
    .order_table td{
      border : 1px solid black;
      padding: 10px;
    }

    .order_table th {
    	border : 1px solid black;
      	padding: 10px;
    	background-color: lightgray;
    }

	</style>
</head>
<body>
<?php include 'nav.php'; ?>

<?php
	session_start();

	if (isset($_SESSION['user_id']))
	{	
		$username = $_SESSION['name'];
		$admin = $_SESSION['admin'];
		if ($admin != '1')
		{
			echo "not admin";
			header('Location: ../index.php');
		}
	}



	if (isset( $_POST['submit']))
	{
		//when make changes button pressed
		// do following
		require_once("../db_connect.php");

		$order_id = $_POST['order_id'];
		$new_status = $_POST['new_status'];

		$sql = "UPDATE orders SET status = '$new_status' WHERE id = $order_id";

		$result = mysqli_query($con,$sql) or die("something went wrong! plz try again");
		header("Location: orders.php");
	}
	else
	{
?>
<table width="70%" align="center" class="order_table">
	<tr>
		<th>Order Id</th>
		<th>User Id</th>
		<th>Product Id</th>
		<th>Product Image</th>
		<th>Current Status</th>
		<th>Change</th>
	</tr>

	<?php

		include "../db_connect.php";

		$sql = "select o.id as order_id,user_id, c.id as card_id, url, status  from orders o, cards c where o.card_id = c.id;";

		$result = mysqli_query($con,$sql) or die("something went wrong! plz try again");

		while($order = mysqli_fetch_assoc($result))
		{
			$id = $order['order_id'];
			$card_id = $order['card_id'];
			$user_id = $order['user_id'];
			$status = $order['status'];
			$url = $order['url'];
	?>
		<tr>
			<td><?= $id ?></td>
			<td><?= $user_id ?></td>
			<td><?= $card_id ?></td>
			<td><img src='../img/<?= $url ?>' width="100px"></td>
			<td><?= $status?></td>
			<td>
				<form action="" method="post">
					<input type="hidden" value="<?= $id ?>" name="order_id">
					<select name="new_status" required="required">
						<option value="">Select</option>
						<option value="order_placed">Order Placed</option>
						<option value="Shipping">Shipping</option>
						<option value="Hub">At Hub</option>
						<option value="out_for_delivery">Out For Delivery</option>
						<option value="delivered">Delivered</option>
					</select>
					<button type="submit" name="submit"> Make Chnages </button>
				</form>
			</td>
		</tr>
	<?php
		} //close of while loop

	}//close of else 
	?>
</table>


</body>
</html>