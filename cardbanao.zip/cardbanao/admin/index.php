<!DOCTYPE html>
<html>
<head>
	<title>CardBanao :: Admin</title>
	<link rel="stylesheet" type="text/css" href="css/nav.css">
</head>
<body>
	
<?php

	session_start();
	if(!isset($_SESSION['user_id']))
	{
		echo "true";
		header("Location: ../login.php");
		die();
	}
	
	$user_id = $_SESSION['user_id'];

	require_once("../db_connect.php");
	$query = "SELECT * FROM users WHERE id='$user_id'";
    $result = mysqli_query($con, $query) or die("Something went wrong!!");

    $user = mysqli_fetch_array($result);

	if($user['isadmin']!='1')
	{
		header("Location: ../index.php");
		die();
	}
?>

	<?php include "nav.php"; ?>

	<div class="wrapper">
		<h2 style="color: #5796E7;">Welcome Admin!</h2>
		<h3>Here is What You can do</h3>
		<ul>

			<li>View Orders</li>
			<li>Change Status of orders</li>
			<li>Add New Card</li>
		</ul>

	</div>

</body>
</html>
