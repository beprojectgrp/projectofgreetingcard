
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="css/register.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CardBanao : Sign In</title>
  
  <link href='http://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="css/main.css">
</head>
<body>
  <?php
    session_start();
    // handling form using post method
    if (isset($_POST['submit']))
    {
		    require_once("db_connect.php");
		
        $email = $_POST['email'];
        $password =  $_POST['password'];
        
        $query = "SELECT * FROM users WHERE email='$email'";
        $result = mysqli_query($con, $query) or die("Something went wrong!! Please Try Again");

        if($row = mysqli_fetch_array($result))
        {
          // check if password is correct
          if ($row['password'] == $password)
          {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['name'] = $row['name'];
            $_SESSION['admin'] = $row['isadmin'];
            if ($row['isadmin']=='1')
              header("Location: admin/index.php");
            else
              header("Location: index.php");
          }
          else
          {
            $msg = 'Invalid Password!' ;
          }
        }
        else
        {
          $msg = 'Invalid username';
        }
        
    }

  ?>

  <?php include "nav.php"; ?>
  <br>
  <form method="post" action="">

    <h1>Sign In</h1>
      <?php 
        if (isset($msg))
        {
          echo "<p style='color : red; text-align:center;'>$msg</p>";
        }
      ?>
      <label for="mail">Email:</label>
      <input type="email" id="mail" name="email" required>

      <label for="password">Password:</label>
      <input type="password" id="password" name="password" required>
    
    <button type="submit" name="submit">Sign In</button>
  </form>


</body>
</html>
